﻿using System.Web.Mvc;

namespace MVC.Controllers
{
    public class WebAPIController : Controller
    {
        public ActionResult WebAPI()
        {
            return View();
        }
    }
}
